export const Images = {
  background: require('@assets/images/Background.png'),
  episode: require('@assets/images/episode.jpeg'),
};
