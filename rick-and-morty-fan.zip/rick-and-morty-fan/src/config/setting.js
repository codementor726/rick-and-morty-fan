/**
 * Basic Setting Variables Define
 */
export const BaseSetting = {
  name: 'Scorecard',
  displayName: 'Scorecard',
  appVersion: '0.1.0',
};
