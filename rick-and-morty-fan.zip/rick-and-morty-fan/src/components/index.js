import Image from './Image';
import Text from './Text';
import BackButton from './BackButton';
import TabBar from './TabBar';

export {Image, Text, BackButton, TabBar};
